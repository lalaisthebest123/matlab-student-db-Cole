classdef StudentDatabase
    properties
        Students = []
    end
    
    methods
        % Add a new student
        function obj = addStudent(obj, student)
            obj.Students = [obj.Students, student];
        end
        
        % Find a student by ID
        function student = findStudentByID(obj, ID)
            student = [];
            for i = 1:length(obj.Students)
                if obj.Students(i).ID == ID
                    student = obj.Students(i);
                    return;
                end
            end
            if isempty(student)
                error('Student with ID %d not found.', ID);
            end
        end
        
        % Get students by major
        function students = getStudentsByMajor(obj, major)
            students = [];
            for i = 1:length(obj.Students)
                if strcmp(obj.Students(i).Major, major)
                    students = [students, obj.Students(i)];
                end
            end
        end
        
        % Save database to .mat file
        function saveDatabase(obj, filename)
            save(filename, 'obj');
        end
        
        % Load database from .mat file
        function obj = loadDatabase(~, filename)
            loadedData = load(filename, 'obj');
            obj = loadedData.obj;
        end
    end
end
