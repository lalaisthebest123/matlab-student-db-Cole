classdef Student
    properties
        ID
        Name
        Age
        GPA
        Major
    end
    
    methods
        % Constructor
        function obj = Student(ID, Name, Age, GPA, Major)
            obj.ID = ID;
            obj.Name = Name;
            obj.Age = Age;
            obj.GPA = GPA;
            obj.Major = Major;
        end
        
        % Display Student Information
        function displayInfo(obj)
            fprintf('ID: %d\nName: %s\nAge: %d\nGPA: %.2f\nMajor: %s\n', ...
                obj.ID, obj.Name, obj.Age, obj.GPA, obj.Major);
        end
        
        % Update GPA
        function obj = updateGPA(obj, newGPA)
            if newGPA >= 0 && newGPA <= 4.0
                obj.GPA = newGPA;
            else
                error('Invalid GPA value. Must be between 0 and 4.0.');
            end
        end
    end
end
