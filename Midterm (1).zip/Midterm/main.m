% Initialize database
db = StudentDatabase();

% Add sample students
student1 = Student(1, 'Alice', 20, 3.8, 'Engineering');
student2 = Student(2, 'Bob', 22, 3.5, 'Science');
student3 = Student(3, 'Charlie', 21, 2.9, 'Engineering');
db = db.addStudent(student1);
db = db.addStudent(student2);
db = db.addStudent(student3);

% Display all students
disp('All students in the database:');
for i = 1:length(db.Students)
    db.Students(i).displayInfo();
    disp('----------------');
end

% Find a student by ID
disp('Finding student with ID 2:');
student = db.findStudentByID(2);
student.displayInfo();

% Get students by major
disp('Students in Engineering:');
engineeringStudents = db.getStudentsByMajor('Engineering');
for i = 1:length(engineeringStudents)
    engineeringStudents(i).displayInfo();
end

% Visualize data
% GPA Distribution
gpas = [db.Students.GPA];
figure;
histogram(gpas);
title('GPA Distribution');
xlabel('GPA');
ylabel('Number of Students');

% Average GPA by Major
majors = unique({db.Students.Major});
avgGPA = zeros(1, length(majors));
for i = 1:length(majors)
    majorStudents = db.getStudentsByMajor(majors{i});
    avgGPA(i) = mean([majorStudents.GPA]);
end
figure;
bar(categorical(majors), avgGPA);
title('Average GPA by Major');
xlabel('Major');
ylabel('Average GPA');

% Age Distribution
ages = [db.Students.Age];
figure;
histogram(ages);
title('Age Distribution');
xlabel('Age');
ylabel('Number of Students');

% Save the database
db.saveDatabase('StudentDatabase.mat');

% Load the database
loadedDb = db.loadDatabase('StudentDatabase.mat');
disp('Database loaded successfully.');
